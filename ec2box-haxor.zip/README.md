# Loading extension

1. [Follow these instructions][]

[Follow these instructions]: https://developer.chrome.com/extensions/getstarted#unpacked

# NOTE
This extension won't work for anyone because I didn't make it generic
enough, but whatever :/
